#!/usr/bin/env bash
set -euo pipefail
make
./box_blur "${1:-samples/sample.pgm}" "${2:-samples/blurred.pgm}" "${3:-1}"
