#include <cuda_runtime.h>

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#define CUDA_CHECK(call) do { \
    cudaError_t err = (call); \
    if (err != cudaSuccess) { \
        std::fprintf(stderr, "CUDA error at %s:%d: %s\n", __FILE__, __LINE__, \
                     cudaGetErrorString(err)); \
        std::exit(EXIT_FAILURE); \
    } \
} while (0)

struct Image {
    int width = 0;
    int height = 0;
    std::vector<unsigned char> pixels;
};

static std::string readToken(std::istream& in) {
    std::string token;
    char ch;
    while (in.get(ch)) {
        if (ch == '#') {
            std::string ignored;
            std::getline(in, ignored);
            continue;
        }
        if (!std::isspace(static_cast<unsigned char>(ch))) {
            token += ch;
            break;
        }
    }
    while (in.get(ch)) {
        if (std::isspace(static_cast<unsigned char>(ch))) break;
        token += ch;
    }
    return token;
}

static Image loadPgm(const std::string& path) {
    std::ifstream in(path, std::ios::binary);
    if (!in) throw std::runtime_error("Cannot open input file: " + path);

    const std::string magic = readToken(in);
    if (magic != "P5" && magic != "P2") {
        throw std::runtime_error("Unsupported image format. Use PGM P5 or P2.");
    }

    Image image;
    image.width = std::stoi(readToken(in));
    image.height = std::stoi(readToken(in));
    const int maxValue = std::stoi(readToken(in));
    if (image.width <= 0 || image.height <= 0 || maxValue <= 0 || maxValue > 255) {
        throw std::runtime_error("Invalid PGM dimensions or max value (expected 1..255).");
    }

    const size_t count = static_cast<size_t>(image.width) * image.height;
    image.pixels.resize(count);
    if (magic == "P5") {
        in.read(reinterpret_cast<char*>(image.pixels.data()),
                static_cast<std::streamsize>(count));
        if (in.gcount() != static_cast<std::streamsize>(count)) {
            throw std::runtime_error("Input PGM pixel data is incomplete.");
        }
    } else {
        for (size_t i = 0; i < count; ++i) {
            const int value = std::stoi(readToken(in));
            if (value < 0 || value > maxValue) {
                throw std::runtime_error("PGM pixel value is outside the allowed range.");
            }
            image.pixels[i] = static_cast<unsigned char>(
                (value * 255 + maxValue / 2) / maxValue);
        }
    }
    if (maxValue != 255 && magic == "P5") {
        for (auto& pixel : image.pixels) {
            pixel = static_cast<unsigned char>(
                (static_cast<int>(pixel) * 255 + maxValue / 2) / maxValue);
        }
    }
    return image;
}

static void savePgm(const std::string& path, const Image& image) {
    std::ofstream out(path, std::ios::binary);
    if (!out) throw std::runtime_error("Cannot open output file: " + path);
    out << "P5\n" << image.width << " " << image.height << "\n255\n";
    out.write(reinterpret_cast<const char*>(image.pixels.data()),
              static_cast<std::streamsize>(image.pixels.size()));
    if (!out) throw std::runtime_error("Failed while writing output image.");
}

__global__ void boxBlurKernel(const unsigned char* input,
                              unsigned char* output,
                              int width, int height, int radius) {
    const int x = blockIdx.x * blockDim.x + threadIdx.x;
    const int y = blockIdx.y * blockDim.y + threadIdx.y;
    if (x >= width || y >= height) return;

    int sum = 0;
    int count = 0;
    for (int dy = -radius; dy <= radius; ++dy) {
        const int yy = y + dy;
        if (yy < 0 || yy >= height) continue;
        for (int dx = -radius; dx <= radius; ++dx) {
            const int xx = x + dx;
            if (xx < 0 || xx >= width) continue;
            sum += input[yy * width + xx];
            ++count;
        }
    }
    output[y * width + x] =
        static_cast<unsigned char>((sum + count / 2) / count);
}

static void printUsage(const char* program) {
    std::cerr << "Usage: " << program
              << " <input.pgm> <output.pgm> [radius]\n"
              << "Supported input formats: PGM P5 (binary) and P2 (ASCII).\n"
              << "Radius defaults to 1; radius must be >= 1.\n";
}

int main(int argc, char** argv) {
    if (argc < 3 || argc > 4) {
        printUsage(argv[0]);
        return EXIT_FAILURE;
    }

    try {
        const int radius = (argc == 4) ? std::stoi(argv[3]) : 1;
        if (radius < 1 || radius > 32) {
            throw std::runtime_error("Radius must be between 1 and 32.");
        }

        Image input = loadPgm(argv[1]);
        Image output;
        output.width = input.width;
        output.height = input.height;
        output.pixels.resize(input.pixels.size());

        const size_t bytes = input.pixels.size() * sizeof(unsigned char);
        unsigned char* deviceInput = nullptr;
        unsigned char* deviceOutput = nullptr;
        CUDA_CHECK(cudaMalloc(&deviceInput, bytes));
        CUDA_CHECK(cudaMalloc(&deviceOutput, bytes));

        CUDA_CHECK(cudaMemcpy(deviceInput, input.pixels.data(), bytes,
                              cudaMemcpyHostToDevice));

        const dim3 block(16, 16);
        const dim3 grid((input.width + block.x - 1) / block.x,
                        (input.height + block.y - 1) / block.y);

        cudaEvent_t start, stop;
        CUDA_CHECK(cudaEventCreate(&start));
        CUDA_CHECK(cudaEventCreate(&stop));
        CUDA_CHECK(cudaEventRecord(start));
        boxBlurKernel<<<grid, block>>>(deviceInput, deviceOutput,
                                       input.width, input.height, radius);
        CUDA_CHECK(cudaGetLastError());
        CUDA_CHECK(cudaEventRecord(stop));
        CUDA_CHECK(cudaEventSynchronize(stop));

        float milliseconds = 0.0f;
        CUDA_CHECK(cudaEventElapsedTime(&milliseconds, start, stop));
        CUDA_CHECK(cudaMemcpy(output.pixels.data(), deviceOutput, bytes,
                              cudaMemcpyDeviceToHost));

        CUDA_CHECK(cudaEventDestroy(start));
        CUDA_CHECK(cudaEventDestroy(stop));
        CUDA_CHECK(cudaFree(deviceInput));
        CUDA_CHECK(cudaFree(deviceOutput));

        savePgm(argv[2], output);
        std::cout << "Input: " << argv[1] << "\n"
                  << "Output: " << argv[2] << "\n"
                  << "Dimensions: " << input.width << " x " << input.height << "\n"
                  << "Blur radius: " << radius << "\n"
                  << "GPU kernel time: " << milliseconds << " ms\n"
                  << "Status: success\n";
    } catch (const std::exception& error) {
        std::cerr << "Error: " << error.what() << "\n";
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}
