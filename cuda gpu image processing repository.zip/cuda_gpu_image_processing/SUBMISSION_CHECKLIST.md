# Submission checklist

- [ ] Create a public GitHub/GitLab repository and upload these project files.
- [ ] Check that the README build and run instructions match your environment.
- [ ] Build and run on a CUDA-enabled machine.
- [ ] Save the genuine terminal output and generated output image.
- [ ] Upload the execution evidence ZIP to the Coursera proof-of-execution field.
- [ ] Record a 5–10 minute demonstration explaining the goal, code, run, and results.

No execution log is included because the program must be run in your own CUDA environment to produce genuine evidence.
