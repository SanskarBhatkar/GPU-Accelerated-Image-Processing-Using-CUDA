# GPU-Accelerated Image Processing with CUDA

## Overview
This project applies a square box blur to a grayscale image using an NVIDIA CUDA GPU. Each CUDA thread calculates one output pixel by averaging the valid pixels in a square neighborhood around it. The implementation supports PGM images in binary `P5` and ASCII `P2` formats with pixel values up to 255.

## Requirements
- NVIDIA GPU supported by your installed CUDA Toolkit
- CUDA Toolkit with `nvcc`
- GNU Make
- C++17-capable host compiler

## Build
From the repository root:

```bash
make
```

Or compile directly:

```bash
nvcc -O2 -std=c++17 src/box_blur.cu -o box_blur
```

## Run
```bash
./box_blur samples/sample.pgm samples/blurred.pgm 1
```

Arguments:
1. Input PGM image
2. Output PGM image
3. Optional blur radius (default `1`, allowed range `1..32`)

A successful run prints the input/output paths, image dimensions, blur radius, GPU kernel time, and a success status. The output is written as a binary PGM (`P5`) file.

You can also run:

```bash
./run.sh
```

Or customize the paths:

```bash
./run.sh input.pgm output.pgm 2
```

## Algorithm
For each output pixel, a CUDA thread:
1. Finds the pixel's neighborhood using the selected radius.
2. Ignores neighbors outside the image boundaries.
3. Sums valid grayscale values and counts them.
4. Stores the rounded average in the output image.

The image is divided into 16 x 16 CUDA thread blocks. The grid dimensions are rounded up so all pixels are covered; threads beyond the image boundary return without writing.

## Testing and evidence
Use a real CUDA-enabled environment to build and run the program. Save the terminal output and output image as evidence. For example:

```bash
script -q execution_log.txt -c './box_blur samples/sample.pgm samples/blurred.pgm 1'
```

Inspect `samples/blurred.pgm` with an image viewer that supports PGM, or convert it to PNG with an image utility. Do not treat a successful compilation alone as proof that the kernel ran correctly.

## Limitations
- This is a grayscale image-processing demonstration, not a color-image pipeline.
- The simple neighborhood loop is intended for clarity; larger radii may be slow.
- GPU execution requires a working NVIDIA CUDA installation. This source has not been pre-certified for every CUDA Toolkit/GPU combination.

## Repository contents
- `src/box_blur.cu`: CUDA kernel and command-line program
- `samples/sample.pgm`: generated sample grayscale input
- `Makefile`: build/run/clean targets
- `run.sh`: convenience build-and-run script
